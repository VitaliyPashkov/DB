﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class OrganizerForm : Form
    {
        public OrganizerForm()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.Viev = new System.Windows.Forms.GroupBox();
            this.AllEvents = new System.Windows.Forms.RadioButton();
            this.AllByCategory = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.EventList = new System.Windows.Forms.ComboBox();
            this.Viev.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Viev
            // 
            this.Viev.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.Viev, 2);
            this.Viev.Controls.Add(this.AllEvents);
            this.Viev.Controls.Add(this.EventList);
            this.Viev.Controls.Add(this.AllByCategory);
            this.Viev.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Viev.Location = new System.Drawing.Point(3, 12);
            this.Viev.Name = "Viev";
            this.Viev.Size = new System.Drawing.Size(500, 77);
            this.Viev.TabIndex = 0;
            this.Viev.TabStop = false;
            this.Viev.Text = "Viev";
            this.Viev.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // AllEvents
            // 
            this.AllEvents.AutoSize = true;
            this.AllEvents.Location = new System.Drawing.Point(12, 50);
            this.AllEvents.Name = "AllEvents";
            this.AllEvents.Size = new System.Drawing.Size(76, 19);
            this.AllEvents.TabIndex = 1;
            this.AllEvents.TabStop = true;
            this.AllEvents.Text = "All events";
            this.AllEvents.UseVisualStyleBackColor = true;
            // 
            // AllByCategory
            // 
            this.AllByCategory.AutoSize = true;
            this.AllByCategory.Location = new System.Drawing.Point(12, 25);
            this.AllByCategory.Name = "AllByCategory";
            this.AllByCategory.Size = new System.Drawing.Size(104, 19);
            this.AllByCategory.TabIndex = 0;
            this.AllByCategory.TabStop = true;
            this.AllByCategory.Text = "All by category";
            this.AllByCategory.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.Viev, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.28081F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.8442F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.875F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(533, 309);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // EventList
            // 
            this.EventList.FormattingEnabled = true;
            this.EventList.Location = new System.Drawing.Point(226, 24);
            this.EventList.Name = "EventList";
            this.EventList.Size = new System.Drawing.Size(256, 23);
            this.EventList.TabIndex = 1;
            this.EventList.SelectedIndexChanged += new System.EventHandler(this.EventList_SelectedIndexChanged);
            // 
            // OrganizerForm
            // 
            this.ClientSize = new System.Drawing.Size(533, 309);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "OrganizerForm";
            this.Text = "OrganizerForm";
            this.Load += new System.EventHandler(this.OrganizerForm_Load);
            this.Viev.ResumeLayout(false);
            this.Viev.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private void OrganizerForm_Load(object sender, EventArgs e)
        {
            EventList.Items.Add("Meeting");
            EventList.Items.Add("Memo");
            EventList.Items.Add("Task");
            EventList.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void EventList_SelectedIndexChanged(object sender, EventArgs e)
        {
       

        }
    }
}
